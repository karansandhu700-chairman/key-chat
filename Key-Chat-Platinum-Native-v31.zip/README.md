# Key Chat — Platinum Native (v31 testing candidate)
This is the complete merged source tree from the uploaded key-chat-main.zip, with the previous Platinum Studio and Intelligence files integrated. No deployment has been made.

## Start testing
Extract this archive to a new folder. From the folder containing index.html, run:
```
python3 -m http.server 8765
```
Open http://localhost:8765/ in a desktop browser. For an iPhone use a private HTTPS staging site or a suitable local-development HTTPS server. A plain HTTP LAN IP may disable secure-context features (service workers, PIN cryptographic APIs, camera). The file:// protocol is not a supported full-app test environment.

The root index.html is the original main chat, not a substitute. The Work button opens the original coding workspace. The sidebar includes File Studio (kc29-studio.html), Research & intelligence (kc-intelligence.html), Discover, and Models & routing. The plus menu provides access to existing tools. New users get Platinum Light; existing background preferences are retained. Dark mode: Settings > General > Background > Obsidian Dark. The same theme is used in the added workspaces.

## Testing and deployment
The app can be staged as a static site; a server is required for secure production credential storage, user authentication, and authenticated integrations. Do not deploy over your existing site until tested. Existing browser data is origin-dependent. Export/back up your old chat data and test in a separate browser profile or staging origin. Do not assume history migrates across origins. GitHub Actions browser checks are included from the original repository (not run in the authoring environment).

## AI and research
Configure your original AI providers through Settings. Existing model routing, streaming, history, memory, PIN screen and coding agent are retained from the original source. The new routing health panel runs short completion requests against up to three configured models; results update the original statistics. Requests may incur charges. A configured model is not necessarily operational.
Research is a separate workspace. It needs a compatible search API (default Tavily endpoint), and optionally an OpenAI-compatible synthesis endpoint. Citations are checked against retrieved source IDs, not verified for claim-level entailment. Studio is browser-local; its exports have basic layouts, PDF uses print/save as PDF.

## Security
This is NOT a hardened production system. Original browser-side provider storage remains by default. In Settings > Security and login, optionally enable session-only chat credentials. This strips provider keys, the relay token and Work GitHub token from future saved state; it does not securely erase old backups, connector secrets, or encrypt local chat data. No server-side accounts, encrypted sync or OAuth directory is provided. The original agent and media/connector/sync features are retained but not independently audited. Do not use real sensitive data in untrusted previews or staging.

An updated optional Cloudflare relay restricts exact Origin values, allowed upstream hosts, methods, request body size and redirects. Existing relay deployments do not change automatically. To use the new worker, configure RELAY_TOKEN and ALLOWED_ORIGINS (comma-separated exact origins, e.g. https://example.github.io, without paths). The relay does not replace client-side provider key management. Only deploy it after reviewing worker code and settings.

See TEST-RESULTS.md for what was actually tested and what remains unverified. ORIGINAL-README.md contains original project setup details.
